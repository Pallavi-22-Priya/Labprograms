package com.cg.spring.lab3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
