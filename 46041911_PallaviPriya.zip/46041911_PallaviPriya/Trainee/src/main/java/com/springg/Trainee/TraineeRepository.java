package com.springg.Trainee;


import org.springframework.data.repository.CrudRepository;

public interface TraineeRepository extends CrudRepository<Trainee, Integer> {
}