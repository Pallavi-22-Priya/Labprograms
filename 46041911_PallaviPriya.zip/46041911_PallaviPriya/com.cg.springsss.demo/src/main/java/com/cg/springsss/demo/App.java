package com.cg.springsss.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println( "Start" );
        ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
        Employee employee = context.getBean("employee", Employee.class);
       System.out.println(employee.toString());
       SBU  sbu=context.getBean("sbu",SBU.class);
       System.out.println(sbu.toString());
    }

	
}
