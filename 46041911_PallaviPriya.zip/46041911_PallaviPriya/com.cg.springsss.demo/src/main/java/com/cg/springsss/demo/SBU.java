package com.cg.springsss.demo;

public class SBU {
	private int sId;
	private String sName;
	private String sHead;
	public SBU()
	{
		
	}
	public SBU(int sId,String sName,String sHead)
	{
		super();
		this.sId=sId;
		this.sName=sName;
		this.sHead=sHead;
	}
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsHead() {
		return sHead;
	}
	public void setsHead(String sHead) {
		this.sHead = sHead;
	}
	@Override
	public String toString() {
		return "SBU [sId=" + sId + ", sName=" + sName + ", sHead=" + sHead + "]";
	}

}
